package com.example.data.services;

import com.example.data.domain.MedicalEncounter;

public interface MedicalEncounterService {
    MedicalEncounter save(MedicalEncounter medicalEncounter);
}
